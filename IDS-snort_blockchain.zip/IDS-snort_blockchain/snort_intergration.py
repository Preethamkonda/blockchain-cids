# -*- coding: utf-8 -*-
"""
Created on Wed Oct  4 16:11:22 2023

@author: user
"""

# snort_blockchain_integration.py

import requests
import matplotlib.pyplot as plt

class SnortRule:
    def __init__(self, action, protocol, source_ip, source_port, direction, dest_ip, dest_port, options=None):
        self.action = action
        self.protocol = protocol
        self.source_ip = source_ip
        self.source_port = source_port
        self.direction = direction
        self.dest_ip = dest_ip
        self.dest_port = dest_port
        self.options = options

    def __str__(self):
        rule_str = f"{self.action.upper()} {self.protocol.upper()} {self.source_ip} {self.source_port} {self.direction} {self.dest_ip} {self.dest_port}"
        if self.options:
            rule_str += f" ({self.options})"
        return rule_str

class IPv6Plugin:
    def __init__(self):
        self.rules = []

    def add_rule(self, rule):
        if isinstance(rule, SnortRule):
            self.rules.append(rule)
        else:
            print("Invalid rule format. Rule must be an instance of SnortRule.")

    def generate_rules(self):
        generated_rules = ""
        for rule in self.rules:
            generated_rules += str(rule) + '\n'
        return generated_rules

def fetch_blockchain_data(api_endpoint, api_key):
    try:
        headers = {"Authorization": f"Bearer {api_key}"}
        response = requests.get(api_endpoint, headers=headers)
        response.raise_for_status()

        if response.status_code == 200:
            return response.json()
        else:
            print(f"Failed to fetch blockchain data. Status code: {response.status_code}")
            return None

    except requests.exceptions.RequestException as e:
        print(f"Error during the request: {e}")
        return None

def create_graph(blockchain_data):
    timestamps = [entry['timestamp'] for entry in blockchain_data]
    values = [entry['value'] for entry in blockchain_data]

    plt.plot(timestamps, values, marker='o')
    plt.xlabel('Timestamp')
    plt.ylabel('Value')
    plt.title('Blockchain Data Over Time')
    plt.xticks(rotation=45)
    plt.show()

def main():
    # Replace these values with your actual blockchain API details
    blockchain_api_endpoint = "https://api.example.com/blockchain"
    blockchain_api_key = "your_api_key"

    # Fetch blockchain data
    blockchain_data = fetch_blockchain_data(blockchain_api_endpoint, blockchain_api_key)

    if blockchain_data:
        # Display fetched blockchain data
        print("Fetched Blockchain Data:")
        for entry in blockchain_data:
            print(f"Timestamp: {entry['timestamp']}, Value: {entry['value']}")

        # Create a graph
        create_graph(blockchain_data)

    # Example Snort rules and plugin usage
    ipv6_plugin = IPv6Plugin()

    # Example Rule 1: Alert on TCP traffic from any source to any destination
    rule1 = SnortRule(action="alert", protocol="tcp", source_ip="any", source_port="any", direction="->",
                      dest_ip="any", dest_port="any", options="msg:'IPv6 TCP Traffic'")
    ipv6_plugin.add_rule(rule1)

    # Example Rule 2: Drop UDP traffic from a specific source to a specific destination
    rule2 = SnortRule(action="drop", protocol="udp", source_ip="2001:db8::1", source_port="any", direction="->",
                      dest_ip="2001:db8::2", dest_port="53", options="msg:'Drop DNS traffic from source to destination'")
    ipv6_plugin.add_rule(rule2)

    # Generate and print the rules
    generated_rules = ipv6_plugin.generate_rules()
    print("\nGenerated Snort Rules:")
    print(generated_rules)

if __name__ == "__main__":
    main()
