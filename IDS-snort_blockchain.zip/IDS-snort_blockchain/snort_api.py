# snort_api.py

def analyze_snort_logs(log_file):
    try:
        with open(log_file, 'r') as file:
            lines = file.readlines()

            #  Count the number of alerts
            alert_count = sum(1 for line in lines if 'Alert' in line)

            # Print the first 10 lines
            print("First 10 lines of Snort log:")
            for i, line in enumerate(lines[:10]):
                print(f"{i + 1}: {line.strip()}")

            print(f"\nTotal number of alerts: {alert_count}")

    except FileNotFoundError:
        print(f"Error: Log file '{log_file}' not found.")

if __name__ == "__main__":
    # Replace with the actual path to your Snort log file
    snort_log_file = "/path/to/snort.log"

    analyze_snort_logs(snort_log_file)
