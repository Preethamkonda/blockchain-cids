# ipv6_plugin.py

class SnortRule:
    def __init__(self, action, protocol, source_ip, source_port, direction, dest_ip, dest_port, options=None):
        self.action = action
        self.protocol = protocol
        self.source_ip = source_ip
        self.source_port = source_port
        self.direction = direction
        self.dest_ip = dest_ip
        self.dest_port = dest_port
        self.options = options

    def __str__(self):
        rule_str = f"{self.action.upper()} {self.protocol.upper()} {self.source_ip} {self.source_port} {self.direction} {self.dest_ip} {self.dest_port}"
        if self.options:
            rule_str += f" ({self.options})"
        return rule_str


class IPv6Plugin:
    def __init__(self):
        self.rules = []

    def add_rule(self, rule):
        if isinstance(rule, SnortRule):
            self.rules.append(rule)
        else:
            print("Invalid rule format. Rule must be an instance of SnortRule.")

    def generate_rules(self):
        generated_rules = ""
        for rule in self.rules:
            generated_rules += str(rule) + '\n'
        return generated_rules


# Example Usage:

if __name__ == "__main__":
    ipv6_plugin = IPv6Plugin()

    # Example Rule 1: Alert on TCP traffic from any source to any destination
    rule1 = SnortRule(action="alert", protocol="tcp", source_ip="any", source_port="any", direction="->",
                      dest_ip="any", dest_port="any", options="msg:'IPv6 TCP Traffic'")
    ipv6_plugin.add_rule(rule1)

    # Example Rule 2: Drop UDP traffic from a specific source to a specific destination
    rule2 = SnortRule(action="drop", protocol="udp", source_ip="2001:db8::1", source_port="any", direction="->",
                      dest_ip="2001:db8::2", dest_port="53", options="msg:'Drop DNS traffic from source to destination'")
    ipv6_plugin.add_rule(rule2)

    # Generate and print the rules
    generated_rules = ipv6_plugin.generate_rules()
    print(generated_rules)
